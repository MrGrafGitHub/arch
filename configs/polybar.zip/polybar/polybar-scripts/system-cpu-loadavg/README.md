# Script: system-cpu-loadavg

A shell script which displays the cpu loadavg. It is a simple script. Very simple.


## Module

```ini
[module/system-cpu-loadavg]
type = custom/script
exec = ~/polybar-scripts/system-cpu-loadavg.sh
interval = 5
```
