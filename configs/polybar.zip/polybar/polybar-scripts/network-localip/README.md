# Script: network-localip

This script shows the local IP of the current connection.

![network-localip](screenshots/1.png)


## Module

```ini
[module/network-localip]
type = custom/script
exec = ~/polybar-scripts/network-localip.sh
interval = 60
```
