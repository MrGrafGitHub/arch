# Script: updates-xbps

A script that shows if there are updates for xbps-based distributions like Void Linux.


## Module

```ini
[module/updates-xbps]
type = custom/script
exec = ~/polybar-scripts/updates-xbps.sh
interval = 20
```
