# Script: info-tmux-sessions

A simple script to show tmux sessions.

![info-tmux-sessions](screenshots/1.png)
![info-tmux-sessions](screenshots/2.png)


## Module

```ini
[module/info-tmux-sessions]
type = custom/script
exec = ~/polybar-scripts/info-tmux-sessions.sh
interval = 5
```
